<?php

use GuzzleHttp\Client;

class Mahasiswa_model extends CI_model
{
    private $_client;

    public function __construct()
    {
        $this->_client = new Client([
            'base_uri' => 'http://localhost/fatur_sembako/'
        ]);
    }

    public function getAllSembako()
    {

        $response = $this->_client->request('GET', 'FaturSembako');

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['message'];
    }

    public function getSembakoId($id)
    {
        $response = $this->_client->request('GET', 'FaturSembako', [
            'query' => [
                'id' => $id
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['message'][0];
    }

    public function tambahSembako()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "gambar" => $this->input->post('gambar', true),
            "harga" => $this->input->post('harga', true)
        ];

        $response = $this->_client->request('POST', 'FaturSembako', [
            'form_params' => $data
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result;
    }

    public function hapusSembako($nama)
    {
        $response = $this->_client->delete('FaturSembako', [
            'form_params' => [
                'nama' => $nama,
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);
        return $result;
    }

    public function ubahDataSembako()
    {
        $data = [
            "id" => $this->input->post('id', true),
            "nama" => $this->input->post('nama', true),
            "gambar" => $this->input->post('gambar', true),
            "harga" => $this->input->post('harga', true),

        ];

        $response = $this->_client->request('PUT', 'FaturSembako', [
            'form_params' => $data
        ]);

        $result = json_decode($response->getBody()->getContents(), true);
        return $result;
    }

    public function cariDataMahasiswa()
    {
        // $keyword = $this->input->post('keyword', true);
        // $this->db->like('nama', $keyword);
        // $this->db->or_like('gambar', $keyword);
        // $this->db->or_like('harga', $keyword);
        // return $this->db->get('mahasiswa')->result_array();
        return false;
    }
}
